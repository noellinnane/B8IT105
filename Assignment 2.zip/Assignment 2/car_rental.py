class Car(object):
    def __init__(self):
        self.colour = ''
        self.make = ''
        self.model = ''
        self.mileage = ''

class PetrolCar():
    def __init__(self):
        Car.__init__(self)
        self.engineSize = ''
        self.noCylinders = ''

class DieselCar():
    def __init__(self):
        Car.__init__(self)
        self.engineSize = ''
        self.fuelType = 'Diesel'
 
class ElectricCar():
    def __init__(self):
        Car.__init__(self)
        self.noFuelCells = ''
        
class HybridCar():
    def __init__(self):
        Car.__init__(self)
        self.engineSize = ''
        self.noFuelCells = ''
       
class CarStock():
    def __init__(self):
        self.petrol_cars = []
        self.diesel_cars = []
        self.electric_cars = []
        self.hybrid_cars = []
        for i in range(1, 21):
            self.petrol_cars.append(PetrolCar())
        for i in range(1,9):
            self.diesel_cars.append(DieselCar())
        for i in range(1, 5):
            self.electric_cars.append(ElectricCar())
        for i in range(1, 9):
            self.hybrid_cars.append(HybridCar())
    
    def getStock(self):
        print('There are ', str(len(self.petrol_cars)), ' petrol cars in stock')
        print('There are ', str(len(self.diesel_cars)), ' diesel cars in stock')
        print('There are ', str(len(self.electric_cars)), ' electric cars in stock')
        print('There are ', str(len(self.hybrid_cars)), ' hybrid cars in stock')

    def petrolStock(self):
        return len(self.petrol_cars)

    def dieselStock(self):
        return len(self.diesel_cars)

    def electricStock(self):
        return len(self.electric_cars)

    def hybridStock(self):
        return len(self.hybrid_cars)

    def totalStock(self):
        return len(self.petrol_cars)+len(self.diesel_cars)+len(self.electric_cars)+len(self.hybrid_cars)
        
    def rentCar(self, type):
        if type.lower() == 'p' and self.petrolStock() > 0:
            return self.petrol_cars.pop()
        elif type.lower() == 'p' and self.petrolStock() == 0:
            print('***No petrol cars available***')
        elif type.lower() == 'd' and self.dieselStock() > 0:
            return self.diesel_cars.pop()
        elif type.lower() == 'd' and self.dieselStock() == 0:
            print('***No diesel cars availabe***')
        elif type.lower() == 'e' and self.electricStock() > 0:
            return self.electric_cars.pop()
        elif type.lower() == 'e' and self.electricStock() == 0:
            print('***No electric cars available***')
        elif type.lower() == 'h' and self.hybridStock() > 0:
            return self.hybrid_cars.pop()
        elif type.lower() == 'h' and self.hybridStock() == 0:
            print('***No hybrid cars available***')

        
    def returnCar(self, type):
        if type.lower() == 'p' and self.petrolStock() < 20:
            return self.petrol_cars.append(PetrolCar())
        elif type.lower() == 'p' and self.petrolStock() == 20:
            print('*** All petrol cars already in stock ***\n')
        elif type.lower() == 'd' and self.dieselStock() < 8:
            return self.diesel_cars.append(DieselCar())
        elif type.lower() == 'd' and self.dieselStock() == 8:
            print('*** All diesel cars already in stock ***\n')
        elif type.lower() == 'e' and self.electricStock() < 4:
            return self.electric_cars.append(ElectricCar())
        elif type.lower() == 'e' and self.electricStock() == 4:
            print('*** All electric cars already in stock ***\n')
        elif type.lower() == 'h' and self.hybridStock() < 8:
            return self.hybrid_cars.append(HybridCar())
        elif type.lower() == 'h' and self.hybridStock() == 8:
            print('*** All hybrid cars already in stock ***\n')
        
    def mainMenu(self):
        print('Welcome to Aungier Car Rental\n')
        print('Please choose an option from the menu below:\n')
        print('1 - Rent a car')
        print('2 - Return a car')
        print('3 - Check Stock\n')
        print('Press any key to exit\n')
        user_input = input()

        while user_input == '1' or user_input == '2' or user_input == '3':
            if user_input == '1' and self.totalStock() > 0:
                print('Please choose type of car: \n')
                print('P - Petrol Car - Current stock: ', str(self.petrolStock()))
                print('D - Diesel Car - Current stock: ', str(self.dieselStock()))
                print('E - Electric Car - Current stock: ', str(self.electricStock()))
                print('H - Hybrid Car - Current stock: ', str(self.hybridStock()))
                type = input()
                self.rentCar(type)
                self.mainMenu()

            elif user_input == '1' and self.totalStock() == 0:
                print('*** No cars available ***\n')
                self.mainMenu()
                
            elif user_input == '2' and self.totalStock() < 40:
                print('Please choose type of car you are returning:\n')
                print('P - Petrol Car')
                print('D - Diesel Car')
                print('E - Electric Car')
                print('H - Hybrid Car\n')
                type = input()
                self.returnCar(type)  
                self.mainMenu()
               
            elif user_input == '2' and self.totalStock() == 40:
                print('***There are no cars due to be returned***\n')
                self.mainMenu()
                
            elif user_input == '3':
                self.getStock()
                self.mainMenu()
                
            break

if __name__ == '__main__':
    my_fleet = CarStock()
    my_fleet.mainMenu()
    