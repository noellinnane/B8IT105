import unittest

from car_rental import CarStock

class CarTest(unittest.TestCase):
    def testStock(self):
        my_fleet = CarStock()
        
        self.assertEqual(40, my_fleet.totalStock()) # Test total stock to begin with equals 40 cars
        
        my_fleet.rentCar('p') # rent 1 petrol car
        self.assertEqual(39, my_fleet.totalStock()) # Test total stock decreases by 1 when a car is rented
        self.assertEqual(19, my_fleet.petrolStock()) # Test Petrol Car stock specifically decreases by 1
       
        my_fleet.returnCar('p') #return 1 petrol car
        self.assertEqual(20, my_fleet.petrolStock()) # Test petrol stock increases by 1 when car is returned
        self.assertEqual(40, my_fleet.totalStock()) # Test total stock increases to 40 when car is returned
        
        my_fleet.returnCar('p') #try to return 1 more petrol car than we have 
        self.assertEqual(20, my_fleet.petrolStock()) # Test that user cannot return more cars than we started out with, i.e. we have 20 petrol cars, if customer attempts to return another error and no change to stock
        
        
if __name__ == '__main__':
    unittest.main()