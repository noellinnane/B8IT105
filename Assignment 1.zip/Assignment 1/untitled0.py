# -*- coding: utf-8 -*-
"""
Created on Mon Sep 24 20:33:13 2018

@author: Noel
"""

$ sudo pip install plotly
#import plotly.offline as py