### Calculator Application

## Import Libraries
import math

## Define Functions

# Addition
def add(a,b):
    return a + b

# Subraction	
def subtract(a,b):
    return a - b

# Multiplication
def multiply(a,b):
    return a * b

# Division
# Exception Handling: Zero Division	
def divide(a,b):
    if b == 0:
        return 'Cannot divide by zero'
    return a / b

# Squares	
def square(a):
    return a ** 2

# Cubes	
def cube(a):  
    return a ** 3

# Exponential
def exponent(a,b):   
    return a ** b

# Square Root
# Exception Handling: Positive numbers only
def root(a):
    if a < 0:
        return 'Must be a positive number'    
    return math.sqrt(a)

# Modulus
def modulus(a,b):    
    return a % b

# Factorial
# Exception Handling: Postive numbers only	
def fact(a):
    if a < 0:
        return 'Must be a positive number'
    return math.factorial(a)
