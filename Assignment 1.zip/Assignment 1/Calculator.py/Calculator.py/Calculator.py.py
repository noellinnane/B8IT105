##Calculator Application

## Import libraries
import math

## Functions
def add(a,b):
    return a + b

def subtract(a,b):
    return a - b

def multiply(a,b):
    return a * b

def divide(a,b):
    if b == 0:
        return 'Cannot divide by zero'
    return a / b

def square(a):
    return a ** 2

def cube(a):
    return a ** 3

def exponent(a,b):
    return a ** b

def squareroot(a):
    return math.sqrt(a)

def fact(a):
    return math.factorial(a)

def modulus(a,b):
    return a % b

print(divide(1,0))
