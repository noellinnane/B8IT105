### Unit Test Script for Calc.py

## Import Libraries
import unittest

## Import functions from script to be tested
from calc import add, subtract, multiply, divide, square, cube, exponent, root, modulus, fact

class CalculatorTest(unittest.TestCase):

    def testAdd(self):
        self.assertEqual(4, add(2, 2))
        self.assertEqual(2,add(2,0))
        self.assertEqual(-1, add(2,-3))
        
    def testSubtract(self):
        self.assertEqual(4,subtract(10,6))
        self.assertEqual(0,subtract(5,5))
        self.assertEqual(-1,subtract(5,6))
        
    def testMultiply(self):
        self.assertEqual(4,multiply(2,2))
        self.assertEqual(0,multiply(2,0))
        self.assertEqual(-1,multiply(1,-1))
        
    def testDivide(self):
        self.assertEqual(4,divide(20,5))
        self.assertEqual(1,divide(2,2))
        self.assertEqual('Cannot divide by zero',divide(5,0))
    
    def testSquare(self):
        self.assertEqual(4,square(2))
        self.assertEqual(9,square(3))
        self.assertEqual(9,square(-3))
        
    def testCube(self):
        self.assertEqual(27,cube(3))
        self.assertEqual(-8,cube(-2))
        
    def testExponent(self):
        self.assertEqual(4,exponent(2,2))
        self.assertEqual(27,exponent(3,3))
        self.assertEqual(16,exponent(2,4))
        self.assertEqual(16,exponent(-2,4))
        self.assertEqual(-8,exponent(-2,3))
        
    def testRoot(self):
        self.assertEqual(2,root(4))
        self.assertEqual('Must be a positive number',root(-9))
        
    def testModulus(self):
        self.assertEqual(0,modulus(10,5))
        self.assertEqual(0,modulus(21,7))
        self.assertEqual(1,modulus(10,9))
        self.assertEqual(0,modulus(35,17.5))

    def testFact(self):
        self.assertEqual(1,fact(1))  
        self.assertEqual(2,fact(2))
        self.assertEqual(6,fact(3))
        self.assertEqual('Must be a positive number',fact(-5))

unittest.main()