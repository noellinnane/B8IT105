changes_file = 'changes_python.log'

the_changes = open(changes_file)
data = the_changes.readlines()
the_changes.close()

print(len(data))

sep = '-'*72+ '\n'

commits = []
index = 0 #start at start of file
while index < len(data): #while we're not at the end of the filed
    details = data[index + 1].split(' | ')
    commit = {'revision':details[0], 'author':details[1], 'date':details[2]}
    print(details)
    index = 6000